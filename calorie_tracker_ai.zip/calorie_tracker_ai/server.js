'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const ROOT = __dirname;
loadDotEnv(path.join(ROOT, '.env'));

const PORT = Number(process.env.PORT || 3000);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-5.6';
const DATA_DIR = path.join(ROOT, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new DatabaseSync(path.join(DATA_DIR, 'calorie_tracker.sqlite'));
db.exec(`
  PRAGMA journal_mode = WAL;
  CREATE TABLE IF NOT EXISTS foods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    canonical_key TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL,
    serving_description TEXT NOT NULL DEFAULT '',
    serving_grams REAL NOT NULL DEFAULT 0,
    kcal REAL NOT NULL,
    carb REAL NOT NULL DEFAULT 0,
    protein REAL NOT NULL DEFAULT 0,
    fat REAL NOT NULL DEFAULT 0,
    source_type TEXT NOT NULL DEFAULT 'manual',
    confidence REAL NOT NULL DEFAULT 1,
    source_urls TEXT NOT NULL DEFAULT '[]',
    use_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_foods_display_name ON foods(display_name);
`);

const FOOD_RESULT_SCHEMA = {
  type: 'object',
  properties: {
    recognized: { type: 'boolean' },
    confidence: { type: 'number', minimum: 0, maximum: 1 },
    summary_name: { type: 'string' },
    serving_description: { type: 'string' },
    kcal: { type: 'number', minimum: 0 },
    carb: { type: 'number', minimum: 0 },
    protein: { type: 'number', minimum: 0 },
    fat: { type: 'number', minimum: 0 },
    needs_web_search: { type: 'boolean' },
    reason: { type: 'string' },
    items: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string' },
          portion_grams: { type: 'number', minimum: 0 },
          kcal: { type: 'number', minimum: 0 },
          carb: { type: 'number', minimum: 0 },
          protein: { type: 'number', minimum: 0 },
          fat: { type: 'number', minimum: 0 }
        },
        required: ['name', 'portion_grams', 'kcal', 'carb', 'protein', 'fat'],
        additionalProperties: false
      }
    }
  },
  required: ['recognized', 'confidence', 'summary_name', 'serving_description', 'kcal', 'carb', 'protein', 'fat', 'needs_web_search', 'reason', 'items'],
  additionalProperties: false
};

const WEB_RESULT_SCHEMA = {
  type: 'object',
  properties: {
    found: { type: 'boolean' },
    confidence: { type: 'number', minimum: 0, maximum: 1 },
    summary_name: { type: 'string' },
    serving_description: { type: 'string' },
    kcal: { type: 'number', minimum: 0 },
    carb: { type: 'number', minimum: 0 },
    protein: { type: 'number', minimum: 0 },
    fat: { type: 'number', minimum: 0 },
    reason: { type: 'string' },
    items: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string' },
          portion_grams: { type: 'number', minimum: 0 },
          kcal: { type: 'number', minimum: 0 },
          carb: { type: 'number', minimum: 0 },
          protein: { type: 'number', minimum: 0 },
          fat: { type: 'number', minimum: 0 }
        },
        required: ['name', 'portion_grams', 'kcal', 'carb', 'protein', 'fat'],
        additionalProperties: false
      }
    }
  },
  required: ['found', 'confidence', 'summary_name', 'serving_description', 'kcal', 'carb', 'protein', 'fat', 'reason', 'items'],
  additionalProperties: false
};

function loadDotEnv(file) {
  if (!fs.existsSync(file)) return;
  const text = fs.readFileSync(file, 'utf8');
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const i = line.indexOf('=');
    if (i < 1) continue;
    const key = line.slice(0, i).trim();
    let value = line.slice(i + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    if (!(key in process.env)) process.env[key] = value;
  }
}

function normalizeFoodName(name) {
  return String(name || '')
    .normalize('NFKC')
    .trim()
    .toLocaleLowerCase('ko-KR')
    .replace(/\s+/g, '');
}

function cleanNumber(value, max = 10000) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(max, Math.max(0, n)) : 0;
}

function getFoodByName(name) {
  const key = normalizeFoodName(name);
  if (!key) return null;
  const row = db.prepare('SELECT * FROM foods WHERE canonical_key = ?').get(key);
  if (!row) return null;
  return serializeFood(row);
}

function serializeFood(row) {
  let urls = [];
  try { urls = JSON.parse(row.source_urls || '[]'); } catch {}
  return {
    id: row.id,
    canonicalKey: row.canonical_key,
    name: row.display_name,
    servingDescription: row.serving_description || '',
    servingGrams: Number(row.serving_grams || 0),
    kcal: Number(row.kcal),
    carb: Number(row.carb),
    protein: Number(row.protein),
    fat: Number(row.fat),
    sourceType: row.source_type,
    confidence: Number(row.confidence || 0),
    sourceUrls: urls,
    useCount: Number(row.use_count || 0),
    updatedAt: row.updated_at
  };
}

function upsertFood(food) {
  const name = String(food.name || food.summary_name || '').trim();
  const key = normalizeFoodName(name);
  const kcal = cleanNumber(food.kcal);
  if (!key || kcal <= 0) return null;

  const sourceType = ['manual', 'vision', 'web'].includes(food.sourceType) ? food.sourceType : 'manual';
  const existing = db.prepare('SELECT * FROM foods WHERE canonical_key = ?').get(key);
  if (existing && existing.source_type === 'manual' && sourceType !== 'manual') return serializeFood(existing);
  if (existing && sourceType !== 'manual' && Number(existing.confidence || 0) > cleanNumber(food.confidence, 1)) return serializeFood(existing);

  const now = new Date().toISOString();
  const params = {
    key,
    name,
    servingDescription: String(food.servingDescription || food.serving_description || '').trim(),
    servingGrams: cleanNumber(food.servingGrams ?? food.serving_grams ?? 0, 5000),
    kcal,
    carb: cleanNumber(food.carb, 1000),
    protein: cleanNumber(food.protein, 1000),
    fat: cleanNumber(food.fat, 1000),
    sourceType,
    confidence: cleanNumber(food.confidence ?? (sourceType === 'manual' ? 1 : 0), 1),
    sourceUrls: JSON.stringify(Array.isArray(food.sourceUrls) ? food.sourceUrls.slice(0, 12) : []),
    now
  };

  if (existing) {
    db.prepare(`UPDATE foods SET display_name=@name, serving_description=@servingDescription, serving_grams=@servingGrams,
      kcal=@kcal, carb=@carb, protein=@protein, fat=@fat, source_type=@sourceType, confidence=@confidence,
      source_urls=@sourceUrls, updated_at=@now WHERE canonical_key=@key`).run(params);
  } else {
    db.prepare(`INSERT INTO foods(canonical_key, display_name, serving_description, serving_grams, kcal, carb, protein, fat,
      source_type, confidence, source_urls, created_at, updated_at)
      VALUES(@key,@name,@servingDescription,@servingGrams,@kcal,@carb,@protein,@fat,@sourceType,@confidence,@sourceUrls,@now,@now)`).run(params);
  }
  return getFoodByName(name);
}

function rememberAnalysis(result, sourceType, sourceUrls = []) {
  if (!result || !result.summary_name || cleanNumber(result.kcal) <= 0) return;
  upsertFood({
    name: result.summary_name,
    servingDescription: result.serving_description,
    kcal: result.kcal,
    carb: result.carb,
    protein: result.protein,
    fat: result.fat,
    sourceType,
    confidence: result.confidence,
    sourceUrls
  });
  for (const item of result.items || []) {
    if (!item.name || cleanNumber(item.kcal) <= 0) continue;
    upsertFood({
      name: item.name,
      servingDescription: item.portion_grams > 0 ? `약 ${Math.round(item.portion_grams)}g` : '',
      servingGrams: item.portion_grams,
      kcal: item.kcal,
      carb: item.carb,
      protein: item.protein,
      fat: item.fat,
      sourceType,
      confidence: result.confidence,
      sourceUrls
    });
  }
}

async function callOpenAI(payload) {
  if (!OPENAI_API_KEY) throw new Error('OPENAI_API_KEY_NOT_CONFIGURED');
  const response = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${OPENAI_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = data?.error?.message || `OpenAI API error ${response.status}`;
    const err = new Error(message);
    err.status = response.status;
    throw err;
  }
  return data;
}

function extractOutputText(response) {
  if (typeof response?.output_text === 'string') return response.output_text;
  const chunks = [];
  for (const item of response?.output || []) {
    if (item?.type !== 'message') continue;
    for (const part of item.content || []) {
      if ((part?.type === 'output_text' || part?.type === 'text') && typeof part.text === 'string') chunks.push(part.text);
    }
  }
  return chunks.join('\n').trim();
}

function parseStructuredResponse(response) {
  const text = extractOutputText(response);
  if (!text) throw new Error('AI가 구조화된 결과를 반환하지 않았습니다.');
  try { return JSON.parse(text); }
  catch { throw new Error('AI 응답을 해석하지 못했습니다.'); }
}

function collectSourceUrls(value) {
  const set = new Set();
  const visit = (node, depth = 0) => {
    if (depth > 8 || node == null) return;
    if (Array.isArray(node)) return node.forEach(x => visit(x, depth + 1));
    if (typeof node !== 'object') return;
    for (const [key, val] of Object.entries(node)) {
      if (key === 'url' && typeof val === 'string' && /^https?:\/\//i.test(val)) set.add(val);
      else visit(val, depth + 1);
    }
  };
  visit(value);
  return [...set].slice(0, 12);
}

function validNutrition(result) {
  return result && result.recognized !== false && cleanNumber(result.kcal) > 0 &&
    [result.carb, result.protein, result.fat].every(v => Number.isFinite(Number(v)) && Number(v) >= 0);
}

async function analyzeVision(imageDataUrl) {
  const system = `너는 한국 사용자를 위한 음식 사진 영양 분석기다. 사진 속 음식의 종류와 실제 보이는 양을 식별하고, 그 사진에 보이는 섭취량 기준으로 열량(kcal), 탄수화물(g), 단백질(g), 지방(g)을 추정한다.
정확성 규칙:
- 음식 정체가 불분명하면 추측해서 확정하지 말고 recognized=false 또는 needs_web_search=true로 둔다.
- 포장식품이면 사진에서 브랜드/제품명이 읽히는 범위에서만 제품명을 구체화한다.
- 여러 음식이 있으면 items에 각각 기록하고 summary 값은 사진 전체의 합계로 계산한다.
- 사진만으로 영양성분을 신뢰하기 어려운 경우 needs_web_search=true로 둔다.
- confidence는 음식 식별과 1회 섭취량 추정의 전체 신뢰도를 0~1로 보수적으로 평가한다.
- 결과는 한국어 음식명으로 작성한다.`;
  const response = await callOpenAI({
    model: OPENAI_MODEL,
    input: [
      { role: 'system', content: system },
      { role: 'user', content: [
        { type: 'input_text', text: '이 음식 사진을 분석해 주세요. 칼로리와 탄수화물·단백질·지방을 사진에 보이는 전체 섭취량 기준으로 계산하세요.' },
        { type: 'input_image', image_url: imageDataUrl, detail: 'high' }
      ] }
    ],
    text: { format: { type: 'json_schema', name: 'food_photo_analysis', strict: true, schema: FOOD_RESULT_SCHEMA } },
    max_output_tokens: 1400
  });
  return parseStructuredResponse(response);
}

async function analyzeWithWeb(imageDataUrl, vision) {
  const candidate = vision?.summary_name || '';
  const system = `너는 음식 사진과 웹 검색을 함께 사용하는 영양정보 검증기다. 먼저 사진과 1차 후보를 비교하고, 반드시 웹 검색을 사용해 가장 유사하고 일치도가 높은 음식/제품을 찾는다.
검색 우선순위:
1) 식품의약품안전처/식품안전나라 등 공공 영양 데이터
2) 제조사·브랜드 공식 제품 페이지와 공식 영양표
3) 공신력 있는 식품 영양 데이터베이스
4) 그 외 신뢰 가능한 자료
판정 규칙:
- 사진과 검색 결과의 음식 종류, 외형, 브랜드/제품명, 구성 재료, 1회 제공량을 비교한다.
- 같은 일반 음식이라도 '김치찌개'와 '돼지고기 김치찌개'처럼 재료가 달라지는 이름은 구분한다.
- 근거가 약하거나 서로 다른 음식일 가능성이 높으면 found=false로 둔다.
- 여러 음식이 있으면 items에 각각 기록하고 summary는 사진 전체 합계다.
- 웹상의 100g 또는 1회 제공량 정보를 사진의 추정 섭취량에 맞춰 환산할 수 있다.
- 검색 근거 없이 숫자를 만들어내지 않는다.`;

  const response = await callOpenAI({
    model: OPENAI_MODEL,
    reasoning: { effort: 'low' },
    tools: [{
      type: 'web_search',
      search_content_types: ['text', 'image'],
      image_settings: { max_results: 5, caption: true }
    }],
    tool_choice: 'auto',
    include: ['web_search_call.action.sources', 'web_search_call.results'],
    input: [
      { role: 'system', content: system },
      { role: 'user', content: [
        { type: 'input_text', text: `1차 사진 인식 후보: ${candidate || '불명확'}\n1차 분석 사유: ${vision?.reason || '없음'}\n사진과 웹 검색 결과를 비교해 가장 높은 일치도의 음식/제품을 찾고, 사진 전체 섭취량 기준 영양성분을 계산하세요. 검색으로 충분히 확인되지 않으면 found=false로 답하세요.` },
        { type: 'input_image', image_url: imageDataUrl, detail: 'high' }
      ] }
    ],
    text: { format: { type: 'json_schema', name: 'food_web_match', strict: true, schema: WEB_RESULT_SCHEMA } },
    max_output_tokens: 1800
  });
  return { result: parseStructuredResponse(response), sources: collectSourceUrls(response) };
}

async function analyzeFoodImage(imageDataUrl) {
  if (!OPENAI_API_KEY) {
    return {
      status: 'manual_required',
      method: 'none',
      confidence: 0,
      message: 'AI 분석 서버의 OPENAI_API_KEY가 아직 설정되지 않았습니다. 직접 입력한 음식 정보는 데이터베이스에 저장됩니다.',
      sourceUrls: [],
      items: []
    };
  }

  let vision = null;
  try {
    vision = await analyzeVision(imageDataUrl);
    const accepted = validNutrition(vision) && Number(vision.confidence) >= 0.78 && !vision.needs_web_search;
    if (accepted) {
      rememberAnalysis(vision, 'vision', []);
      return {
        status: 'recognized', method: 'vision', confidence: Number(vision.confidence),
        name: vision.summary_name, servingDescription: vision.serving_description,
        kcal: cleanNumber(vision.kcal), carb: cleanNumber(vision.carb, 1000), protein: cleanNumber(vision.protein, 1000), fat: cleanNumber(vision.fat, 1000),
        message: vision.reason || 'AI가 사진을 인식해 영양성분을 계산했습니다.', sourceUrls: [], items: vision.items || []
      };
    }
  } catch (err) {
    console.warn('[vision analysis failed]', err.message);
    vision = { summary_name: '', reason: err.message, confidence: 0, recognized: false, needs_web_search: true };
  }

  try {
    const web = await analyzeWithWeb(imageDataUrl, vision);
    const r = web.result;
    const accepted = r?.found === true && validNutrition({ ...r, recognized: true }) && Number(r.confidence) >= 0.7;
    if (accepted) {
      rememberAnalysis(r, 'web', web.sources);
      return {
        status: 'searched', method: 'web', confidence: Number(r.confidence),
        name: r.summary_name, servingDescription: r.serving_description,
        kcal: cleanNumber(r.kcal), carb: cleanNumber(r.carb, 1000), protein: cleanNumber(r.protein, 1000), fat: cleanNumber(r.fat, 1000),
        message: r.reason || 'AI 인식이 불확실해 웹 검색으로 유사 음식과 영양정보를 확인했습니다.', sourceUrls: web.sources, items: r.items || []
      };
    }
    return {
      status: 'manual_required', method: 'none', confidence: Number(r?.confidence || vision?.confidence || 0),
      message: r?.reason || 'AI 인식과 웹 검색으로도 충분히 일치하는 음식 정보를 찾지 못했습니다. 직접 입력해 주세요. 저장하면 다음부터 같은 음식명 입력 시 자동으로 채워집니다.',
      sourceUrls: web.sources, items: []
    };
  } catch (err) {
    console.warn('[web fallback failed]', err.message);
    return {
      status: 'manual_required', method: 'none', confidence: Number(vision?.confidence || 0),
      message: 'AI 인식 결과를 확정하지 못했고 웹 검색도 완료하지 못했습니다. 직접 입력해 주세요. 저장된 값은 다음 입력부터 자동으로 불러옵니다.',
      sourceUrls: [], items: []
    };
  }
}

function sendJson(res, status, value) {
  const body = JSON.stringify(value);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body), 'Cache-Control': 'no-store' });
  res.end(body);
}

function readJson(req, maxBytes = 8 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let total = 0;
    const chunks = [];
    req.on('data', chunk => {
      total += chunk.length;
      if (total > maxBytes) {
        const err = new Error('요청 데이터가 너무 큽니다.');
        err.status = 413;
        reject(err);
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); }
      catch { const err = new Error('JSON 요청 형식이 올바르지 않습니다.'); err.status = 400; reject(err); }
    });
    req.on('error', reject);
  });
}

function serveStatic(req, res, pathname) {
  const filePath = pathname === '/' ? path.join(ROOT, 'index.html') : path.join(ROOT, pathname.replace(/^\/+/, ''));
  const safe = path.resolve(filePath);
  if (!safe.startsWith(path.resolve(ROOT) + path.sep) && safe !== path.join(ROOT, 'index.html')) {
    res.writeHead(403); res.end('Forbidden'); return;
  }
  if (!fs.existsSync(safe) || !fs.statSync(safe).isFile()) {
    res.writeHead(404); res.end('Not found'); return;
  }
  const ext = path.extname(safe).toLowerCase();
  const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml' };
  res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  fs.createReadStream(safe).pipe(res);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = url.pathname;

    if (req.method === 'GET' && pathname === '/api/health') {
      return sendJson(res, 200, { ok: true, aiConfigured: Boolean(OPENAI_API_KEY), model: OPENAI_MODEL, database: 'sqlite' });
    }

    if (req.method === 'GET' && pathname === '/api/foods/lookup') {
      const name = url.searchParams.get('name') || '';
      const food = getFoodByName(name);
      if (food) db.prepare('UPDATE foods SET use_count = use_count + 1 WHERE id = ?').run(food.id);
      return sendJson(res, 200, { found: Boolean(food), food });
    }

    if (req.method === 'POST' && pathname === '/api/foods/manual') {
      const body = await readJson(req, 256 * 1024);
      const name = String(body.name || '').trim();
      if (!name) return sendJson(res, 400, { ok: false, message: '음식 이름이 필요합니다.' });
      if (!(Number(body.kcal) > 0)) return sendJson(res, 400, { ok: false, message: '칼로리는 0보다 커야 합니다.' });
      const food = upsertFood({ ...body, sourceType: 'manual', confidence: 1, sourceUrls: [] });
      return sendJson(res, 200, { ok: true, food });
    }

    if (req.method === 'POST' && pathname === '/api/foods/analyze') {
      const body = await readJson(req);
      const imageDataUrl = String(body.imageDataUrl || '');
      if (!/^data:image\/(?:jpeg|jpg|png|webp);base64,/i.test(imageDataUrl)) {
        return sendJson(res, 400, { status: 'manual_required', message: '분석할 이미지 형식이 올바르지 않습니다.' });
      }
      const result = await analyzeFoodImage(imageDataUrl);
      return sendJson(res, 200, result);
    }

    if (req.method === 'GET') return serveStatic(req, res, pathname);
    res.writeHead(405); res.end('Method not allowed');
  } catch (err) {
    console.error(err);
    if (!res.headersSent) sendJson(res, err.status || 500, { ok: false, message: err.message || '서버 오류가 발생했습니다.' });
    else res.end();
  }
});

server.listen(PORT, () => {
  console.log(`Calorie Tracker: http://localhost:${PORT}`);
  console.log(`AI: ${OPENAI_API_KEY ? `enabled (${OPENAI_MODEL})` : 'disabled - set OPENAI_API_KEY in .env'}`);
  console.log(`Food DB: ${path.join(DATA_DIR, 'calorie_tracker.sqlite')}`);
});
